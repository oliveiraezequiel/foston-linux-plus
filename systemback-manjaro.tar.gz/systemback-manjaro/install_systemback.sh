#!/bin/bash

# Define variables
TAR_FILE="Systemback_Install_Pack_v1.8.402.tar.xz"
EXTRACT_DIR="systemback_install_pack"
CONVERTED_DIR="converted_packages"

# Step 1: Extract the .tar.xz file
mkdir -p $EXTRACT_DIR
tar -xf $TAR_FILE -C $EXTRACT_DIR

# Step 2: Convert .deb to .pkg.tar.zst using debtap
mkdir -p $CONVERTED_DIR
for deb in $EXTRACT_DIR/*.deb; do
    sudo debtap -u
    sudo debtap "$deb"
    mv *.pkg.tar.zst $CONVERTED_DIR/
done

# Step 3: Install the packages
sudo pacman -U $CONVERTED_DIR/*.pkg.tar.zst

# Clean up
rm -r $EXTRACT_DIR $CONVERTED_DIR

echo "Installation complete!"
echo " da equipe foston linux plus e edxlinux para o manjaro linux"
